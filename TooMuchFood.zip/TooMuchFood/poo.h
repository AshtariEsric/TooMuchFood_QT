#ifndef POO_H
#define POO_H

#include <QGraphicsPixmapItem>

class poo : public QGraphicsPixmapItem
{
public:
    poo(QGraphicsItem *parent = nullptr, QString fail ="");

};

#endif // POO_H
